import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

import { CanvasJSAngularChartsModule } from '@canvasjs/angular-charts';


@Component({
  selector: 'app-analytics',
  standalone: true,
  imports: [CommonModule, RouterOutlet, CanvasJSAngularChartsModule],
  templateUrl: './analytics.component.html',
  styleUrl: './analytics.component.css'
})
export class AnalyticsComponent {
  title = 'angular17ssrapp';
	generateRandomData = () => {
		var y  = 1000, dps = [];
		for(var i = 0; i < 1000; i++) {
			y += Math.ceil(Math.random() * 10 - 5);
			dps.push({ y: y});
		}
		return dps;
	}
	chartOptions = {
	  zoomEnabled: true,
	  exportEnabled: true,
	  theme: "light2",
	  title: {
		text: "Try Zooming & Panning"
	  },
	  data: [{
		type: "line",
		dataPoints: this.generateRandomData()
	  }]
	}

  chartOptions2 = {
    exportEnabled: true,
    animationEnabled: true,
    theme: "dark2",
    title: {
        text: "Monthly Temperature Variation"
    },
    subtitles: [{
        text: "Bengaluru, India",
    }],
    axisX: {
        valueFormatString: "MMMM"
    },
    axisY: {
        title: "Temperature (°C)",
        suffix: "°C"
    },
    data: [{
        type: "rangeSplineArea",
        xValueFormatString: "MMMM YYYY",
        yValueFormatString: "##.#°C",
        toolTipContent: "{x} Min: {y[0]}, Max: {y[1]}",
        color: "#4DD0E1",
        dataPoints: [
            { x: new Date(2019, 0, 1), y: [12.0382, 30.1865] },
            { x: new Date(2019, 1, 1), y: [16.2404, 34.2949] },
            { x: new Date(2019, 2, 1), y: [18.2318, 36.0597] },
            { x: new Date(2019, 3, 1), y: [21.4699, 36.7624] },
            { x: new Date(2019, 4, 1), y: [21.3156, 35.3482] },
            { x: new Date(2019, 5, 1), y: [21.087, 33.3196] },
            { x: new Date(2019, 6, 1), y: [19.8427, 31.6698] },
            { x: new Date(2019, 7, 1), y: [20.3135, 30.1392] },
            { x: new Date(2019, 8, 1), y: [20.1342, 30.303] },
            { x: new Date(2019, 9, 1), y: [18.8909, 30.5804] },
            { x: new Date(2019, 10, 1), y: [16.4149, 30.3919] },
            { x: new Date(2019, 11, 1), y: [14.7093, 29.8572] }
        ]
    }]
}

chartOptions3 = {
  animationEnabled: true,
  exportEnabled: true,
  theme: "dark2",
  title: {
    text: "Server CPU Utilization vs Active Users"
  },
  axisX: {
    title: "Active Users"
  },
  axisY: {
    title: "CPU Utilization",
    suffix: "%"
  },
  legend: {
    cursor: "pointer",
    itemclick: function(e:any) {
          if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible ){
                e.dataSeries.visible = false;
          } else {
                e.dataSeries.visible = true;
          }
          e.chart.render();
    }
  },
  data: [
  //   {
  //   type: "scatter",
  //   name: "Server 1",
  //   markerType: "cross",
  //   yValueFormatString: "##.## %",
  //   showInLegend: true,
  //   toolTipContent: "<span style='\"'color: {color};'\"'>{name}</span><br>Active Users: {x}<br>CPU Utilization: {y}",
  //   dataPoints: [
  //     { x: 100, y: 10 },
  //     { x: 110, y: 15 },
  //     { x: 130, y: 17 },
  //     { x: 140, y: 19 },
  //     { x: 145, y: 21 },
  //     { x: 400, y: 25 },
  //     { x: 430, y: 27 },
  //     { x: 444, y: 30 },
  //     { x: 460, y: 29 },
  //     { x: 490, y: 35 },
  //     { x: 500, y: 40 },
  //     { x: 510, y: 50 },
  //     { x: 600, y: 30 },
  //     { x: 700, y: 35 },
  //     { x: 800, y: 40 },
  //     { x: 900, y: 45 },
  //     { x: 1000, y: 47 },
  //     { x: 1200, y: 55 },
  //     { x: 1230, y: 51 },
  //     { x: 1300, y: 60 },
  //     { x: 1330, y: 65 },
  //     { x: 1400, y: 70 },
  //     { x: 1450, y: 71 },
  //     { x: 1500, y: 69 },
  //     { x: 1530, y: 75 },
  //     { x: 1590, y: 79 },
  //     { x: 1600, y: 62 },
  //     { x: 1620, y: 80 },
  //     { x: 1640, y: 85 },
  //     { x: 1700, y: 81 },
  //     { x: 1790, y: 89 },
  //     { x: 1800, y: 91 },
  //     { x: 1950, y: 93 },
  //     { x: 1980, y: 88 },
  //     { x: 2000, y: 90 }
  //   ]
  // },
  {
    type: "scatter",
    name: "Server 2",
    showInLegend: true,
    markerType: "circle",
    toolTipContent: "<span style='\"'color: {color};'\"'>{name}</span><br>Active Users: {x}<br>CPU Utilization: {y}%",
    dataPoints: [
      { x: 100, y: 25 },
      { x: 110, y: 35 },
      { x: 130, y: 35 },
      { x: 140, y: 40 },
      { x: 145, y: 45 },
      { x: 400, y: 42 },
      { x: 430, y: 32 },
      { x: 444, y: 35 },
      { x: 460, y: 43 },
      { x: 490, y: 50 },
      { x: 500, y: 57 },
      { x: 510, y: 67 },
      { x: 600, y: 40 },
      { x: 700, y: 46 },
      { x: 800, y: 50 },
      { x: 900, y: 60 },
      { x: 1000, y: 66 },
      { x: 1200, y: 79 },
      { x: 1230, y: 60 },
      { x: 1300, y: 75 },
      { x: 1330, y: 80 },
      { x: 1400, y: 82 },
      { x: 1450, y: 88 },
      { x: 1500, y: 87 },
      { x: 1530, y: 88 },
      { x: 1590, y: 90 },
      { x: 1600, y: 80 },
      { x: 1620, y: 93 },
      { x: 1640, y: 91 },
      { x: 1700, y: 92 },
      { x: 1790, y: 93 },
      { x: 1800, y: 90 },
      { x: 1950, y: 91 },
      { x: 1980, y: 93 },
      { x: 2000, y: 95 }
    ]
  }]
}	
}    


